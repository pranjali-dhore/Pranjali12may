package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;

public class FilmDaoImplForList implements IFilmDao{
	private Map<Integer, film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Drama", 0));
		categories.add(new Category(2, "Comedy",0));
		categories.add(new Category(3, "Horror",0));
		categories.add(new Category(4, "Scientific",0));
		categories.add(new Category(5, "Romantic",0));
		categories.add(new Category(6, "Action",0));
		
		
		return categories;
	}

	@Override
	public Map<Integer, film> getAllFilms() {
		
		 return film_Repository;
	}

	@Override
	public void addFilm(film fm) {
		film_Repository.put(fm.getFilm_id(), fm);
		
	}

	@Override
	public film searchFilm(int filmId1)
	{
		Map<Integer, film> filmList=getAllFilms();
		Collection<film>filmList1=filmList.values();
		film fm1=new film();
		boolean flag=false;
		for(film f1:filmList1)
		{
			if(filmId1==f1.getFilm_id())
			{
				System.out.println("Film is exists");
				fm1=f1;
				flag=true;
				break;
			}
		}
		
		return fm1 ;
	}

	@Override
	public void updateFilm(film film1) {
		addFilm(film1);
	}
	

}
