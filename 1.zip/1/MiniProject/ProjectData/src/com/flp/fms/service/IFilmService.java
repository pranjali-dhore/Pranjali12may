package com.flp.fms.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;

public interface IFilmService
{
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public void addFilm(film fm);
	public Map<Integer, film> getAllFilms();
	public film searchFilms(int filmId1);
	public void updateFilm(film film1);
	
}
