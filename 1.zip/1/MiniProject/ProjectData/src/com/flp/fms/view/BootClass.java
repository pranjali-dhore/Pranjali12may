package com.flp.fms.view;

import java.sql.Date;
import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import javax.swing.DefaultBoundedRangeModel;

import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;
import com.flp.fms.util.Validate;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
	    IActorService actorServicec = new ActorServiceImpl();
		do
		{
	    menuSelection();
		System.out.println("Enter your Option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				film fm=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServicec.getActor());
				filmService.addFilm(fm);
				System.out.println(fm);
				break;
				
				
			case 2:
				
				
				int filmId1=userInteraction.readFilmId();
				film film1= filmService.searchFilms(filmId1);
				System.out.println("update");
				/*System.out.println(film);*/
				if(film1==null)
					System.out.println("Film Not Present");
				else{
					
					String choice2;
					do{
						
						System.out.println("1.Modify by Title");
					     System.out.println("2.Modify by Ratings");
					     System.out.println("3.Modify All info");
					     System.out.println("4.Exit");
					System.out.println("Enter your option:[1-5]");
					option=sc.nextInt();
					
					switch(option){
					
					//BY TITLE
					case 1:
						System.out.println("Enter title:");
						String title=sc.next();
						film1.setTittle(title);
						film1.setFilm_id(filmId1);
						filmService.updateFilm(film1);
						break;
		
					//BY RATING	
					case 2:
						System.out.println("Enter Rating:");
						int rating=sc.nextInt();
						film1.setRatings(rating);
						film1.setFilm_id(filmId1);
						filmService.updateFilm(film1);
						break;
				
					//BY ALL FIELDS	
					case 3:
						film film2=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServicec.getActor());
						film1.setFilm_id(filmId1);
						filmService.updateFilm(film2);
						break;
					}
					System.out.println("Wish to do more modification?[y|n]");
					choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					}break;
			
			case 3:

				String choice2 = null;
				do{
					
				System.out.println("Enter Your Choice :");
				System.out.println("Enter 1 : Delete By Id");
				System.out.println("Enter 2 : Delete By Tittle");
				System.out.println("Enter 3 : Delete By Rating");
				System.out.println("Enter 4 : Go To Previous Menu");
				
				int opt = sc.nextInt();
				
				if(opt==1)
				{
					Map<Integer, film>  film_lst4= filmService.getAllFilms();
					Collection<film> lst4=film_lst4.values();
					userInteraction.deleteFilm(lst4);
					break;
				}
				else if (opt==2) {
					Map<Integer, film>  film_lst5= filmService.getAllFilms();
					Collection<film> lst5=film_lst5.values();
					userInteraction.DeleteFilmByFilmName(lst5);
					break;
				}
				else if(opt==3){
					Map<Integer, film>  film_lst6= filmService.getAllFilms();
					Collection<film> lst6=film_lst6.values();
					userInteraction.DeleteFilmByRating(lst6);
					break;
				}
				else if(opt==4)
				{
					break;
				}
				else{
					
					System.out.println("Not Valid Choice");
				}
				System.out.println("Enter Your Choice :");
				choice2=sc.next();
				}while(choice2.charAt(0)=='y' ||choice2.charAt(0)=='Y' );
				break;
			case 4:
				String choice1 = null;
				do{
					
				System.out.println("Enter Your Choice :");
				System.out.println("Enter 1 : Search By Id");
				System.out.println("Enter 2 : Search By Tittle");
				System.out.println("Enter 3 : Search By Rating");
				System.out.println("Enter 4 : Go To Previous Menu");
				
				int opt = sc.nextInt();
				
				if(opt==1)
				{
					Map<Integer, film>  film_lst3= filmService.getAllFilms();
					Collection<film> lst3=film_lst3.values();
					userInteraction.searchFilm(lst3);
					break;
				}
				else if (opt==2) {
					Map<Integer, film>  film_lst4= filmService.getAllFilms();
					Collection<film> lst4=film_lst4.values();
					userInteraction.searchFilmByName(lst4);
					break;
				}
				else if(opt==3){
					Map<Integer, film>  film_lst5= filmService.getAllFilms();
					Collection<film> lst5=film_lst5.values();
					userInteraction.searchFilmByRating(lst5);
					break;
				}
				else if(opt==4)
				{
						break;
				}
				else{
					
					System.out.println("Not Valid Choice");
					
				}
				System.out.println("Enter Your Choice :");
				choice1=sc.next();
				}while(choice1.charAt(0)=='y' ||choice1.charAt(0)=='Y' );
				break;
			case 5:
				Map<Integer, film>  film_lst1= filmService.getAllFilms();
				Collection<film> lst1=film_lst1.values();
				userInteraction.getAllFilm(lst1);
				break;
			case 6:
				System.exit(0);
				break;
			default:System.out.println("You have Enter wrong Choice Please Select correct Choice");
			break;
		}
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		}

	public static void menuSelection(){
		System.out.println("--SELECT MENU--");
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}

}
