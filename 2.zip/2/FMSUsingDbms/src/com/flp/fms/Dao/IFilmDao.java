package com.flp.fms.Dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language>getOriginalLanguage();
	public List<Category>getCategory();
	
	
	public void addFilm(Film film);
	
	
	public List<Film> getAllFilms();
	/*public Map<Integer, Film> searchFilm();*/
	
	public int removeFilmByID(int filmID);
	public int removeFilmByTitle(String filmTitle);
	public int removeFilmByRating(int rating);
	
	
	public int updateTitle(String title,int filmID);
	public int updateFilm(Film film1,int filmId);
	
	public List<Film> searchFilmByRating(int rating);

}
