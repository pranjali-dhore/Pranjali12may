package com.flp.fms.domain;

public class Actor {
	//Private fields
	private int actor_Id;
	private String actor_Fname,actor_Lname;
	
	//No Argument Constructor
	public Actor() {
	
	}
	
	//Paramterized Constructor
	public Actor(int actor_Id, String actor_Fname, String actor_Lname) {
		super();
		this.actor_Id = actor_Id;
		this.actor_Fname = actor_Fname;
		this.actor_Lname = actor_Lname;
	}
	
	
	
	//Getters and setters
	public int getActor_Id() {
		return actor_Id;
	}
	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}
	public String getActor_Fname() {
		return actor_Fname;
	}
	public void setActor_Fname(String actor_Fname) {
		this.actor_Fname = actor_Fname;
	}
	public String getActor_Lname() {
		return actor_Lname;
	}
	public void setActor_Lname(String actor_Lname) {
		this.actor_Lname = actor_Lname;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actor_Fname == null) ? 0 : actor_Fname.hashCode());
		result = prime * result + actor_Id;
		result = prime * result + ((actor_Lname == null) ? 0 : actor_Lname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (actor_Fname == null) {
			if (other.actor_Fname != null)
				return false;
		} else if (!actor_Fname.equals(other.actor_Fname))
			return false;
		if (actor_Id != other.actor_Id)
			return false;
		if (actor_Lname == null) {
			if (other.actor_Lname != null)
				return false;
		} else if (!actor_Lname.equals(other.actor_Lname))
			return false;
		return true;
	}

	//Overriden toString() methid
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", actor_Fname=" + actor_Fname + ", actor_Lname=" + actor_Lname + "]";
	}
	
	
	

}
