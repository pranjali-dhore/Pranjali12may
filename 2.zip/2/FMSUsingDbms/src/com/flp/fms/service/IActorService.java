package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorService {
	
	public List<Actor>addActor();

	List<Actor> getActorList();


}
