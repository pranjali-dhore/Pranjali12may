package com.flp.fms.service;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	public List<Language> getLanguage();

	public List<Category> getCategory();

	void addFilm(Film film);

	public List<Film> getAllFilms();
	
	public int removeFilmByID(int filmId);

	//public Film searchFilms(int filmId1);

	public int updateFilm(Film film1,int filmId);

	public Film getSearchFilmByID(int filmId);

	public int removeFilmByTitle(String filmTitle);

	public int removeFilmByRating(int rating);

	public int updateTitle(String title,int filmId);

	public int updateRating(int rating, int filmId1);

	public Film searchFilmByID(int id);

	public List<Film> searchFilmByRating(int rating);

	public Film searchFilmByTitle(String title);

	

}
