package com.flp.fms.view;

import java.awt.Choice;

import java.nio.channels.AcceptPendingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.swing.text.StyledEditorKit.BoldAction;


import org.omg.Messaging.SyncScopeHelper;
import org.omg.PortableServer.SERVANT_RETENTION_POLICY_ID;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	
	
	
	//ADD FILM IN REPOSITORY
	public Film addFilm(List<Language> languageList, List<Category> categoryList,List<Actor>actorList)
	{
		Film film=new Film();
		
		//Title
		String title;
		boolean flag=true;
		
		do{
		System.out.println("Enter Title of the film: ");
		title=sc.nextLine();
		flag=Validate.isValidFilmTitle(title);
		if(!flag)
			System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
	
		//Release Date
		String releaseDate;
		Date realeaseDate1=null;
		boolean date_flag=false;
		do{
			do{
				System.out.println("Enter release Date[dd-mmm-yyyy]:");
				releaseDate=sc.next();
				flag=Validate.isVaildReleaseDAte(releaseDate);
				if(!flag)
					System.out.println("Enter date in [dd-mmm-yyyy] format");
			}while(!flag);
			Date today=new Date();
			realeaseDate1=new Date(releaseDate);
			if(realeaseDate1.before(today)||realeaseDate1.equals(today))
				date_flag=true;
			if(!date_flag)
				System.out.println("Date should be current date or past date");

		}while(!date_flag);
		film.setRealeaseYear(realeaseDate1);
	
	//rentalDuration
		String rentalDuration;
		Date rentalDuration1=null;
		boolean rental_flag=false;
		Date relaeseDay=null;
		do{
			//verify rentalDuration format
			do{
				System.out.println("Enter rental Duration[dd-mmm-yyyy]:");
				rentalDuration=sc.next();
				flag=Validate.isVaildRentalDuration(rentalDuration);
				if(!flag)
					System.out.println("Enter date in [dd-mmm-yyyy] format");
			}while(!flag);

	
	     //verify RentalDuration
			relaeseDay=film.getRealeaseYear();
			rentalDuration1=new Date(rentalDuration);

			if(rentalDuration1.after(relaeseDay))
				rental_flag=true;

			if(!rental_flag)
				System.out.println("Date should be current date or Future date");

		}while(!rental_flag);
		film.setRentalDuration(rentalDuration1);

		//length
		int len;
		do{
			System.out.println("Enter length of the film in minute:");
			len=sc.nextInt();
			flag=Validate.isValidLength(len);
			if(!flag)
				System.out.println("Enter length in(0-1000) range:");
		}while(!flag);
		film.setLength(len);
	
		//replacement cost
		double replacementCost;
		do{
			System.out.println("Enter reolacement cost:");
			replacementCost=sc.nextDouble();
			flag=Validate.isValidCost(replacementCost);
			if(!flag)
				System.out.println("Enetr proper replacement cost:");
		}while(!flag);
		film.setReplacementCost(replacementCost);
	
		//Ratings
		int rating;
		do{
			System.out.println("Enter rating for film:");
			rating=sc.nextInt();
			flag=Validate.isValidRate(rating);
			if(!flag)
				System.out.println("Enter Rating between[1-5]");
		}while(!flag);
		film.setRatings(rating);
	
		//description
		System.out.println("Enter description of film");
		String desc=sc.next();
		film.setDescription(desc);
	
		//SpecialFeature
		System.out.println("Enter Special Feature of film");
		String specialFea=sc.next();
		film.setSpecialFeatures(specialFea);
	
		//Original language
		Language lang=new Language();
		System.out.println("Choose original Language");
		Language language=selectLanguage(languageList);
		film.setOriginalLanguage(language);
	
		//Category
		Category catgry=new Category();
		Category category=selectCategory(categoryList);
		film.setCategory(category);
	
	
	  //ADD OTHER LANGUAGES
			List<Language> languages2=new ArrayList<>();
			String choice;
			boolean flag_langs;
			do{
				System.out.println("Choose Other Languages for the Film:");
				Language language1= selectLanguage(languageList);
				
				
				flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
				if(!flag_langs)
					languages2.add(language1);
				else
					System.out.println("Language already Exists. Please try other languages!");
				
				
				System.out.println("Wish to add More Languages?[y|n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setLanguages(languages2);
	
          //Actor
			List<Actor>actorList1=new ArrayList<>();
			String choice1;
			boolean flag_Actor;
			do{
				System.out.println("Choose the Actors for film:");
				Actor actor=addActor(actorList);
				flag_Actor=Validate.checkDuplicateActorID(actorList1,actor);
				if(!flag_Actor)
					actorList1.add(actor);
				else
					System.out.println("Actor already Exists. Please choose other Actor!");


				System.out.println("Wish to add More Actors?[y|n]");
				choice1=sc.next();
			}while(choice1.charAt(0)=='y'||choice1.charAt(0)=='Y');
			film.setActors(actorList1);

		return film;
	}

	

	



	//TO PASS LANGUAGE
	private Language selectLanguage(List<Language> languageList) {
		Language sel_Language=null;
		boolean flag_orgLang=false;
		
		do{
		//print List of Language
			for(Language lang:languageList)
				System.out.println(lang.getLanguage_Id()+"\t"+lang.getLanguage_Name());
			System.out.println("Choose your option:");
			int option=sc.nextInt();
		for(Language lang:languageList)
		{
			if(option==lang.getLanguage_Id())
			{
				sel_Language=lang;
				flag_orgLang=true;
				break;
			}
		}
			if(!flag_orgLang)
				System.out.println("Please choose correct language:");
	
		}while(!flag_orgLang);
		return sel_Language;
	}
	
	//TO PASS SELECTED CATEGORY
	private Category selectCategory(List<Category> categoryList) {
		Category sel_Category=null;
		boolean flag_Category=false;

		do{
			for(Category cateogry1:categoryList)
				System.out.println(cateogry1.getCategory_Id()+"\t"+cateogry1.getCategory_Name());

			System.out.println("Enter your choice:");
			int option=sc.nextInt();
			for(Category cateogry1:categoryList)
			{
				if(option==cateogry1.getCategory_Id())
				{
					sel_Category=cateogry1;
					flag_Category=true;
					break;
				}
			}
			if(!flag_Category)
				System.out.println("please choose correct category:");

		}while(!flag_Category);



		return sel_Category;
	}

      
	  //TO PASS THE SELECTED ACTOR
       private Actor addActor(List<Actor> actorList) {
			Actor sel_Actor=null;
			boolean flag_Actor=false;
			
			do{
				for(Actor act:actorList)
					System.out.println(act.getActor_Id()+"\t"+act.getActor_Fname()+"\t"+act.getActor_Lname());
				
				System.out.println("Choose your Actor:");
				int option=sc.nextInt();
				
				for(Actor act:actorList)
				{
					if(option==act.getActor_Id())
					{
						sel_Actor=act;
						flag_Actor=true;
						break;
					}
				}
				if(!flag_Actor)
					System.out.println("choose correct Actor ID:");
				
			}while(!flag_Actor);
			
			return sel_Actor;
	}


            //LISTING THE REPOSITORY
			public void getAllFilm(Collection<Film> film_list) {
				
				if(!(film_list.isEmpty()))
				{
					
					System.out.println("Film ID\t\t\tFilm Title\t\tDescription\t\tRelease Year\t\tRental Duration\t\tLength\t\tRating\t\t\tRelplacement Cost\t\tSpecial Features\t\tOrigimnal Language\t\tCategory\t\t Other Languages\t\t Actors");	
					
					
				for(Film film:film_list)
				{
				String lang="";
				StringBuffer actorName=new StringBuffer();
				
				for(Language langs:film.getLanguages())
					lang=lang+langs.getLanguage_Name()+",";
				for(Actor actor:film.getActors())
				{
			
					actorName.append(actor.getActor_Fname()+" "+actor.getActor_Lname()+",");
				//System.out.println(actorName);
				}
				//System.out.println(actorName);
				System.out.println(film.getFilm_Id()+"\t\t\t"+film.getTitle()+"\t\t\t"+film.getDescription()+"\t\t\t"+film.getRealeaseYear()+"\t\t"+film.getRentalDuration()+"\t\t"+film.getLength()+"\t\t"+film.getRatings()+"\t\t\t"+film.getReplacementCost()+"\t\t\t"+film.getSpecialFeatures()+"\t\t\t\t"+film.getOriginalLanguage().getLanguage_Name()+"\t\t\t\t"+film.getCategory().getCategory_Name()+"\t\t\t\t"+lang.substring(0, (lang.length()-1))+"\t\t\t\t"+actorName.substring(0, (actorName.length()-1)));
				}
			}else
				System.out.println("List is empty");
			}







			public void searchFilm(Collection<Film> film_list1) {
				
				boolean flag=false;
				String choice;
				int option;
				do{
					System.out.println("1.Search by ID");
					System.out.println("2.Search by rating");
					System.out.println("3.Search by Title");
					System.out.println("Choose your option:");
					option=sc.nextInt();
					
					if(option==1)
					{
			
						System.out.println("Enter film id to search:");
						int id=sc.nextInt();
						for(Film film:film_list1)
						{
							if(id==film.getFilm_Id())
							{
								System.out.println("Film is exists");
								System.out.println(film);
								flag=true;
								break;
							}
						}
						if(flag==false)
							System.out.println("film not exists");
					}
					
					else if(option==2)
					{
						System.out.println("Enter of what rating films are need to be search:");
						int rating=sc.nextInt();
				
						for(Film film:film_list1)
						{
							if(rating==film.getRatings())
							{
								//System.out.println("Film is exists");
								System.out.println(film);
								/*flag=true;
								break;*/
							}
						}
						if(flag==false)
							System.out.println("film not exists");
					}
					
				
					
					
					else if(option==3)
					{
						for(Film film:film_list1)
						{
							System.err.println("Enter title for the film to search:");
							String title=sc.next();
							if(title.equals(film.getTitle()))
							{
								System.out.println("Film is exists");
								System.out.println(film);
			//					flag=true;
			//					break;
							}
						}
						if(flag==false)
							System.out.println("film not exists");
					}
				
				System.out.println("Wish to continue(y/Y)");
				choice=sc.next();
				
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				
			}
			






		public void removeFilm(Collection<Film> film_list2) {
			boolean flag=false;
			String choice;
			int option;
			do{
				System.out.println("1.Remove by ID");
				System.out.println("2.Remove by rating");
				System.out.println("3.Remove by Title");
				System.out.println("Choose your option:");
				option=sc.nextInt();
				
				if(option==1)
				{
		
					System.out.println("Enter film id to remove the film:");
					int id=sc.nextInt();
					if(!(film_list2.isEmpty()))
					{
					for(Film film:film_list2)
					{
						if(id==film.getFilm_Id())
						{
		//					System.out.println(film);
							film_list2.remove(film);
							System.out.println("Film is removed");
							flag=true;
							break;
						}
					}
					if(flag==false)
						System.out.println("film not exists");
					}
					else 
						System.out.println("list is empty");
				}
				
				else if(option==2)
				{
					System.out.println("Enter of what rating films are need to be remove:");
					int rating=sc.nextInt();
			
					if(!(film_list2.isEmpty()))
					{
		
					for(Film film:film_list2)
					{
						if(rating==film.getRatings())
						{
							//System.out.println("Film is exists");
		//					System.out.println(film);
							film_list2.remove(film);
							/*flag=true;
							break;*/
						}
//						flag=true;
					}
//					if(flag==false)
//						System.out.println("film not exists");
					}
					else 
						System.out.println("list is empty");
				}
				
			
				
				
				else if(option==3)
				{
					System.err.println("Enter title for the film to remove:");
					String title=sc.next();
					if(!(film_list2.isEmpty()))
					{
						for(Film film:film_list2)
						{
							if(title.equals(film.getTitle()))
							{
								//	System.out.println("Film is exists");
								//					System.out.println(film);
								film_list2.remove(film);
								//					flag=true;
								//					break;
							}
							//flag=true;
						}
						/*if(flag==false)
						System.out.println("film not exists");*/
					}
					else 
						System.out.println("list is empty");
				}
			
			System.out.println("Wish to continue(y/Y)");
			choice=sc.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
		}







		public void deleteFilmById(Map<Integer, Film> allFilms, int filmId) {
			
			allFilms.remove(filmId);
			
		}
			
		
		public void deleteFilmByTitle(Map<Integer, Film> allFilms, String filmTitle) {
			int id;
			Set<Integer> keys=allFilms.keySet();
			Iterator<Integer> itr=keys.iterator();
			while(itr.hasNext()){
				{
					Integer key=itr.next();
					if(filmTitle.equals(allFilms.get(key).getTitle()))
					{
					id=	allFilms.get(key).getFilm_Id();
					allFilms.remove(id);
					System.out.println("Object deleted successfully!!");
					}
					else
						System.out.println("Title not match!!");
				}
					
			
		}
			
		}







		@SuppressWarnings("unchecked")
		public void deleteFilmByRatings(Map<Integer, Film> allFilms, int rating) {
		/*	Collection<Film> allFilms = filmRepository.values();
			Iterator<Film> itr = allFilms.iterator();
			
			Set<Integer> selectedFilmIds = new HashSet<>();
			
			while(itr.hasNext()){
				
				Film film = itr.next();
				
				if(film.getRating() == rating){
					
					selectedFilmIds.add(film.getFilm_Id());	
				}
			}
			
			for(Integer filmId : selectedFilmIds){
				
				filmRepository.remove(filmId);
			}*/
			
			
			Collection<Film>fildel=allFilms.values();
			Iterator<Film> itr =  fildel.iterator();
			List<Integer> selectedFilmIds = new ArrayList();
			

			while(itr.hasNext()){
				
				Film film = itr.next();
				
				if(film.getRatings() == rating){
					
					selectedFilmIds.add(film.getFilm_Id());	
				}
			}
			

			for(Integer filmId : selectedFilmIds){
				
				allFilms.remove(filmId);
			}
			
			
		}






		
        //Read ID for Update
		public int readFilmId() {
		System.out.println("Enter the ID to be update:");
			return sc.nextInt();
		}

}
