package com.mkyong.common.Dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;

import com.mkyong.common.pojo.EODBatchProcessCutomer;


public interface EODBatchProcessDaoInterface  {

	public Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) throws IOException;
	public Object getCellValue(Cell cell);
	public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException;
}
