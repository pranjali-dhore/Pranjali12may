package com.mkyong.common.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;

import com.mkyong.common.pojo.EODBatchProcessCutomer;

public interface EODBatchProcessServiceInterface  {

	public Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) throws IOException;
	public Object getCellValue(Cell cell);
	public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException;
}
