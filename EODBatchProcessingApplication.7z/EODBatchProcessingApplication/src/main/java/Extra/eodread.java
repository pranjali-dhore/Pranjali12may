package Extra;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.EOD.EODBatchProcessExcelRead;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.pojo.EODBatchProcessCutomer;

public class eodread {
public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException {
			List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
			
			FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
			Workbook workbook = getWorkbook(inputStream, excelFilePath);
			
			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();
			
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				EODBatchProcessCutomer eodcustomer = new EODBatchProcessCutomer();
				
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					
					
					int columnIndex = nextCell.getColumnIndex();
					
					switch (columnIndex) {
					case 0:
						Double cardno= (Double) getCellValue(nextCell);
						Integer card_no=cardno.intValue();
						eodcustomer.setCard_no(card_no);
											break;
					case 1:
						
						Double custId= (Double) getCellValue(nextCell);
						Integer cust_id=custId.intValue();
						eodcustomer.setCust_id(cust_id);
						
						break;
					case 2:
					
						eodcustomer.setDate_of_transaction((String) getCellValue(nextCell));
						break;
					case 3:
						
						
						eodcustomer.setAmount_debited((double) (getCellValue(nextCell)) );
						break;
					case 4:
				
						eodcustomer.setAmount_credited((double) getCellValue(nextCell));
						break;
					case 5:
						//System.out.println(getCellValue(nextCell));
						eodcustomer.setNet_amount( (double) getCellValue(nextCell));
						break;
					}
					//System.out.println(eodcustomer);
					
				}
				listCustomerTemp.add(eodcustomer);
			}
			
			workbook.close();
			inputStream.close();
			
			return listCustomerTemp;
		}
		
		private Object getCellValue(Cell cell) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				return cell.getStringCellValue();
				
			case Cell.CELL_TYPE_BOOLEAN:
				return cell.getBooleanCellValue();

			case Cell.CELL_TYPE_NUMERIC:
				
				return cell.getNumericCellValue();
				
				
		
			}
			
			return null;
		}
		
		public static void main(String[] args) throws IOException {
			String excelFilePath = "D:\\Customer.xlsx";
			
		/*	File file = new File("D:\\");
	        File[] files = file.listFiles();
	        for(File f: files){
	            System.out.println(f.getName());
	        }
			*/
			EODBatchProcessExcelRead reader = new EODBatchProcessExcelRead();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			System.out.println(listCustomer);
		}

		private Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) 
				throws IOException {
			Workbook workbook = null;
			
			if (excelFilePath.endsWith("xlsx")) {
				workbook = new XSSFWorkbook(inputStream);
			} else if (excelFilePath.endsWith("xls")) {
				workbook = new HSSFWorkbook(inputStream);
			} else {
				throw new IllegalArgumentException("The specified file is not Excel file");
			}
			
			return workbook;
		}
	}


