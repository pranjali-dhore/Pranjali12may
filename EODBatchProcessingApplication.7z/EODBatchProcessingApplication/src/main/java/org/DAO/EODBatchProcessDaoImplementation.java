package org.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.EOD.EODBatchValidator;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.pojo.EODBatchProcessCutomer;

public class EODBatchProcessDaoImplementation implements EODBatchProcessDaoInterface {

	
	public Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) throws IOException {
		Workbook workbook = null;
		
		if (excelFilePath.endsWith("xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		} else if (excelFilePath.endsWith("xls")) {
			workbook = new HSSFWorkbook(inputStream);
		} else {
			throw new IllegalArgumentException("The specified file is not Excel file");
		}
		
		return workbook;
	}
	public Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();
			
		case Cell.CELL_TYPE_BOOLEAN:
			return cell.getBooleanCellValue();

		case Cell.CELL_TYPE_NUMERIC:
			
			return cell.getNumericCellValue();
		}
		
		return null;
	}
	public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException {
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		
		/*final Logger logger = Logger.getLogger(EODBatchProcessExcelRead.class);*/
		final Logger errorlog = Logger.getLogger("errorlogger");
		final Logger successlog = Logger.getLogger("successlogger");
		
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		
		Workbook workbook = getWorkbook(inputStream, excelFilePath);
		
		Sheet firstSheet = workbook.getSheetAt(0);   // Loop for Multi
		Iterator<Row> iterator = firstSheet.iterator();
		
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			EODBatchProcessCutomer eodcustomer = new EODBatchProcessCutomer();
			
			while (cellIterator.hasNext()) {
				Cell nextCell = cellIterator.next();
				
			    boolean flag=false;
				int columnIndex = nextCell.getColumnIndex();
				
				switch (columnIndex) {
				case 0:
					
					Double cardno= (Double) getCellValue(nextCell);
					Integer card_no=cardno.intValue();
					
					flag=EODBatchValidator.isEmptyCardNo((int)card_no);
					
					if(flag)
					{
						
						
					eodcustomer.setCard_no(card_no);
					
					}
					else{
						errorlog.error("Missing Card Number");
					
					}
					break;
				case 1:
					
					Double custId= (Double) getCellValue(nextCell);
					Integer cust_id=custId.intValue();
					flag=EODBatchValidator.isEmptyCustId((int)cust_id);
					
					if(flag){	
					eodcustomer.setCust_id(cust_id);
					}
					else{
						errorlog.error("Missing Customer Id");
					
					}
					break;
				case 2:
				
						flag=EODBatchValidator.isEmptyDate((String) getCellValue(nextCell));
					
					if(flag){
						
						eodcustomer.setDate_of_transaction((String) getCellValue(nextCell));
					}
					else{
						errorlog.error("Missing Date of Transaction");
					}
					break;
				case 3:
					flag=EODBatchValidator.isEmptyAmountDebited((double) (getCellValue(nextCell)) );
				if(flag){
					
					eodcustomer.setAmount_debited((double) (getCellValue(nextCell)) );
				}
				else{
					errorlog.error("Missing Ammount Debited");
				}
					
					break;
				case 4:
			
					flag=EODBatchValidator.isEmptyAmountCredited((double) (getCellValue(nextCell)) );
					if(flag)
					{
						
						eodcustomer.setAmount_credited((double) getCellValue(nextCell));
					}
					else
					{
						errorlog.error("Missing Ammount Credited");
				
					}
					break;
				case 5:
                 flag=EODBatchValidator.isEmptyNetAmount((double) (getCellValue(nextCell)) );
					if(flag)
					{
						eodcustomer.setNet_amount( (double) getCellValue(nextCell));
					}
					else{
						errorlog.error("Missing Net Ammount");
					/*	successlog.info("Hi");*/
					}
					break;
					
					
				}
				
				if(eodcustomer.getCard_no()!=0 && eodcustomer.getCust_id()!=0 && eodcustomer.getDate_of_transaction()!=null && eodcustomer.getAmount_debited()!=0 && eodcustomer.getAmount_credited()!=0 && eodcustomer.getNet_amount()!=0)
				{
					successlog.info("successfull");
				}
				
			}
		
			listCustomerTemp.add(eodcustomer);
		}
		
		workbook.close();
		inputStream.close();
		return listCustomerTemp;
	}
	
}
