package org.EOD;

import com.sun.org.apache.regexp.internal.recompile;

public class EODBatchValidator {

	public static boolean isEmptyCardNo(int card_no) {
		
		
		if(card_no==0)
		{
			return false;
		}
		else
			return true;
		
		
		
	}

	public static boolean isEmptyCustId(int cust_id) {

		if(cust_id==0)
		{
			return false;
		}
		else
			return true;
		
	}

	public static boolean isEmptyDate(String cellValue) {
		
		if(cellValue==null)
		{
			return false;
		}
		else
			return true;
	}

	
	public static boolean isEmptyAmountDebited(double d) {
		if(d==0.0)
		{
			return false;
		}
		else
			return true;
	}

	public static boolean isEmptyAmountCredited(double d) {
		if(d==0.0)
		{
			return false;
		}
		else
			return true;
	}

	public static boolean isEmptyNetAmount(double d) {
		if(d==0.0)
		{
			return false;
		}
		else
			return true;
	}

	
	
	
	
	
}
