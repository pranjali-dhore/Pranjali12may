package org.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.pojo.EODBatchProcessCutomer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EODBatchProcessMainController {
	
	@RequestMapping("/EODBatch")
	public ModelAndView sayHello(){
		return new ModelAndView("EODBatchProcessSucessPage","message","EOD");
	}
	
//......................LoginController...........................
	@RequestMapping("/login")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) {  
        String name=request.getParameter("name");  
        String password=request.getParameter("password");  
          
        if(password.equals("admin")){  
        String message = "Hi "+name+"Login Successful";  
        return new ModelAndView("EODBatchProcessLoginSuccessPage", "message", message);  
        }  
        else{  
            return new ModelAndView("EODBatchProcessLoginErrorPage", "message","Sorry, username or password error");  
        }  
    } 
	
	
	@Autowired
	ServletContext context;
		
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String HelloWorld(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		model.addAttribute("message", "Welcome to Spring MVC");
		return "EODBatchProcessUploadFile";
	}
	
	
	
	
//..............................Read Excel File .......................................
	
	/*public List<EODBatchProcessCutomer> getCustomerDetails(){
		
		
		
	}*/
	
	
}
