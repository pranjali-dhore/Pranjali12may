package org.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.EOD.EODBatchProcessExcelRead;
import org.EOD.EODBatchValidator;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.pojo.EODBatchProcessCutomer;
import org.service.EODBatchProcessServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EODBatchProcessMainController {
	
	@RequestMapping("/EODBatch")
	public ModelAndView sayHello(){
		return new ModelAndView("EODBatchProcessSucessPage","message","EOD");
	}
	
//......................LoginController...........................
	@RequestMapping("/login")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) {  
        String name=request.getParameter("name");  
        String password=request.getParameter("password");  
       
        if(password.equals("admin")){  
        String message = "Hi "+name+"Login Successful";  
        return new ModelAndView("EODBatchProcessLoginSuccessPage", "message", message);  
        }  
        else{  
            return new ModelAndView("EODBatchProcessLoginErrorPage", "message","Sorry, username or password error");  
        }  
    } 
	

	
	
//..............................Main Controller .......................................

	/*@RequestMapping("/trigger")  
	    public ModelAndView ReadExcelFile(HttpServletRequest request,HttpServletResponse res)  {  
		EODBatchProcessExcelRead eodprocessexcelread = new EODBatchProcessExcelRead();
		FileInputStream inputStream = null;
		String excelFilePath = null;
		eodprocessexcelread.getWorkbook(inputStream, excelFilePath);
		System.out.println(eodprocessexcelread);
		
		public List<EODBatchProcessCutomer> readCustFromExcelFile(String excelFilePath) throws IOException {
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		
		/*final Logger logger = Logger.getLogger(EODBatchProcessExcelRead.class);*/
	
	
	@RequestMapping("/trigger")
	public ModelAndView readCustFromExcelFile(HttpServletRequest req, HttpServletResponse res , String excelFilePath) throws IOException {
		
		
		EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
	
		File file = new File("D:\\Customer");
        File[] files = file.listFiles();
        for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
		
		 EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			
			System.out.println();
			System.out.println("Customer - "+i);
			System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
			for(EODBatchProcessCutomer EODCustomer:listCustomer)
				System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
			
			
		}
		return new ModelAndView();
	
	}
	
		
@RequestMapping("/cust")
    public ModelAndView submitupdatevalue(@ModelAttribute("cust") EODBatchProcessCutomer cust,String excelFilePath) throws IOException{
		
		EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
		List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
		ModelAndView result = new ModelAndView("EODBatchProcessSaveHtml");
		File file = new File("D:\\Customer");
        File[] files = file.listFiles();
       //list of customer
        List<EODBatchProcessCutomer>customer=new ArrayList<>();
        for(int i=1;i<=files.length;i++)
		{
        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
		 EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
			List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
			System.out.println();
			System.out.println("Customer - "+i);
			System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
			
			
			//EODBatchProcessCutomer EODCustomer1 = new EODBatchProcessCutomer();
			for(EODBatchProcessCutomer EODCustomer:listCustomer)
			{
				System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
			    cust.setCard_no(EODCustomer.getCard_no());
				cust.setCust_id(EODCustomer.getCust_id());
				cust.setDate_of_transaction(EODCustomer.getDate_of_transaction());
				cust.setAmount_debited(EODCustomer.getAmount_debited());
				cust.setAmount_credited(EODCustomer.getAmount_credited());
				cust.setNet_amount(EODCustomer.getNet_amount());
				//listCustomer.add(cust);
				customer.add(cust);
				
				//result.addObject(cust);
				//maps.put("cust", result);
				//result.addObject(CustomerList, attributeValue)
				 result.addObject(cust);
				}
			//list is added to modelandview object
			 //result.addObject(customer);
			 //return new ModelAndView("EODBatchProcessSaveHtml");
	}
        
       
    //  return new ModelAndView("EODBatchProcessSaveHtml", "cust", result);
      // return new ModelAndView("EODBatchProcessSaveHtml", "cust", result);
      //  System.out.println("result is :"+ result);
      
        System.out.println("size"+customer.size());
        //return new ModelAndView("EODBatchProcessSaveHtml");
   
       // return new ModelAndView("EODBatchProcessSaveHtml", "cust", result);
          return result;
      
      
      //ModelAndView("EODBatchProcessSaveHtml", "cust", result);
   // return new ModelAndView("EODBatchProcessSaveHtml", maps);
}

	
	/*@RequestMapping(value="/cust",method=RequestMethod.GET,
			produces={"application/json"})

	public ModelAndView showOrderPage(@ModelAttribute("cust") EODBatchProcessCutomer cust,Map<String, Object> map ,String excelFilePath) throws IOException{
		  
				map.put( "cust", new EODBatchProcessCutomer());
				
				
				//List<EODBatchProcessCutomer> orderslist=customerService.getAllOrders();
				
				
				EODBatchProcessServiceImplementation eod = new EODBatchProcessServiceImplementation();
				List<EODBatchProcessCutomer> listCustomerTemp = new ArrayList<>();
			
				File file = new File("D:\\Customer");
		        File[] files = file.listFiles();
		        for(int i=1;i<=files.length;i++)
				{
		        	excelFilePath = "D:\\Customer\\Customer"+i+".xlsx";
				
				 EODBatchProcessServiceImplementation reader = new EODBatchProcessServiceImplementation();
					List<EODBatchProcessCutomer> listCustomer = reader.readCustFromExcelFile(excelFilePath);
					
					System.out.println();
					System.out.println("Customer - "+i);
					System.out.println("Card no\t\t\tCustomer ID\t\t\tDate Of Transaction\t\t\tAmount Debited\t\t\tAmount Credited\t\t\tnetAmount");
					
					for(EODBatchProcessCutomer EODCustomer:listCustomer)
					
						{
						System.out.println(EODCustomer.getCard_no()+"\t\t\t"+EODCustomer.getCust_id()+"\t\t\t"+EODCustomer.getDate_of_transaction()+"\t\t\t"+EODCustomer.getAmount_debited()+"\t\t\t"+EODCustomer.getAmount_credited()+"\t\t\t"+EODCustomer.getNet_amount());
						}
				
			    map.put("cust", listCustomer);
				
				 System.out.println(map);
				 
	
				}
		        ModelAndView result = new ModelAndView("EODBatchProcessSaveHtml");  
				result.addAllObjects(map);
				System.out.println("cust obj"+map);
				System.out.println("result is "+result);
		        return result;
	
	}*/
	
}
	

