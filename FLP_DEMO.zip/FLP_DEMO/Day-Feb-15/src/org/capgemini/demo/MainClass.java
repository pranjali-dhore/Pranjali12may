package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		//Create object
		//emp-->reference && new Employee() -->object
		
		Employee emp=new Employee();
		//emp.getEmployee();
		emp.printEmployee();
		

		
		/*System.out.println("FirstName:" + emp.firstName);
		System.out.println("LastName:" + emp.lastName);
		System.out.println("Id:" + emp.getEmpId());
		System.out.println("salary:" + emp.salary);
*/
	}

}
