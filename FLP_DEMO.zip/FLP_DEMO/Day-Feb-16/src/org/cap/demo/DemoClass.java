package org.cap.demo;

import org.capgemini.Student;

public class DemoClass {

	public static void main(String[] args) {
		Student student=new Student();

	}

}
