package org.capgemini;

import java.util.Scanner;

public class Student {
	private int studNo;
	private String firstName,lastName;
	private double fees;
	
	//Constructor
	//no-arg constructor
	public Student(){
		System.out.println("Default Constructor");
		this.studNo=1001;
		this.firstName="Tom";
		this.lastName="Jerry";
		this.fees=4500;
		
	}
	
	//overloaded Constructor
	public Student(int studNo,String fName,String lastName,double fees){
		System.out.println("Overloaded Constructor");
	this.studNo=studNo;
		firstName=fName;
		this.lastName=lastName;
		this.fees=fees;
		
	}
	
	
	public Student(int studNo,String fName){
		System.out.println("Overloaded Constructor");
		this.studNo=studNo;
		firstName=fName;
		
	}
	
	public Student(int studNo,String fName,String lastName){
		
		this(studNo,fName);
		this.lastName=lastName;
	
		
	}
	
	
	
	public Student(Student student){
		this.studNo=student.studNo;
		this.firstName=student.firstName;
		this.lastName=student.lastName;
		this.fees=student.fees;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void getStudentDetails(){
		Scanner sc=new  Scanner(System.in);
		System.out.println("Enter Stduent Id:");
		studNo=sc.nextInt();
		System.out.println("Enter Stduent firstName:");
		firstName=sc.next();
		
		System.out.println("Enter Stduent lastName:");
		lastName=sc.next();
		System.out.println("Enter Stduent Fees:");
		fees=sc.nextDouble();
		
	}
	
	public void printStudentDetails(){
		System.out.println( studNo + "\t" + firstName + 
				"\t" + lastName + "\t" + fees);
	}
	
	

}
