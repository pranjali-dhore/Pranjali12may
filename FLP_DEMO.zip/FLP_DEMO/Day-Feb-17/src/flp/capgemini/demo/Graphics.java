package flp.capgemini.demo;

public interface Graphics {
	
	void animate();
	void move_shape();

}
