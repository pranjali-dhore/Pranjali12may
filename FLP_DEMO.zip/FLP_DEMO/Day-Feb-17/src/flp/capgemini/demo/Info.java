package flp.capgemini.demo;

public interface Info {
	void getInfo();
	void printInfo();

}
