package flp.cap.demo;

import java.util.Scanner;

public class Employee {
	
	int empId=1001;
	String empName="Tom";
	Weekdays holiday=Weekdays.SAT;
	
	public void chooseHoliday(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Sunday");
		System.out.println("2.Monday");
		System.out.println("3.Tuesday");
		System.out.println("4.Wednesday");
		System.out.println("5.Thursday");
		System.out.println("6.Friday");
		System.out.println("7.Saturday");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		
		switch(choice){
			case 1:
				holiday=Weekdays.SUN;
				break;
			case 2:
				holiday=Weekdays.MON;
				break;
			case 3:
				holiday=Weekdays.TUE;
				break;
			case 4:
				holiday=Weekdays.WED;
				break;
			case 5:
				holiday=Weekdays.THU;
				break;
			case 6:
				holiday=Weekdays.FRI;
				break;	
			case 7:
				holiday=Weekdays.SAT;
				break;
		}
		
	}
	
	public void printEmployee(){
		System.out.println(empId+" , " + empName +" , " + holiday);
	}
	
	
	public static void main(String[] args){
		Employee employee=new Employee();
		employee.printEmployee();
	}

}
