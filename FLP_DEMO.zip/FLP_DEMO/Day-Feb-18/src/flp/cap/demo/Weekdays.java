package flp.cap.demo;

public enum Weekdays {
	
	MON(2),TUE(3),WED(4),THU(5),FRI(6),SAT(7),SUN(1);

	private int value;
	
	private Weekdays(int value) {
		this.value=value;
	}
	
	
	public int getValue(){
		return value;
	}
}
