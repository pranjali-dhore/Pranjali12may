package flp.cap.nestedclass;

public class MainClass {

	public static void main(String[] args) {
		Test test=new Test();
		test.method();
		
		
		

	}

}
