package flp.cap.nestedclass;

public interface MyInterface {
	
	public void calculate();

}
