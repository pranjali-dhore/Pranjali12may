package flp.cap.nestedclass;

public class OuterClass {
	
	private int num=500;
	private String str="Tom";
	
	public class InnerClass{
		
		int count=100;
		private int num=1500;
		
		public void innerClsMethod(){
			OuterClass class1=new OuterClass();
			System.out.println("Count:" + count);
			System.out.println("Number:" + class1.num);
			System.out.println("String:" + str);
			System.out.println("inner Class Method");
		}
		
		
	}
	
	
	public void outerClsMethod(){
		System.out.println("Outer Class Method");
	}

}
