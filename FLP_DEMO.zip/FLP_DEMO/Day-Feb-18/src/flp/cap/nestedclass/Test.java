package flp.cap.nestedclass;

public class Test {
	
	private int count=100;
	
	public void method(){
		
		int index=0;
		
		class InnerClass{
			int num;
			public void show(){
				System.out.println("Inner CLass show Method");
				System.out.println("Number :" +num);
				System.out.println("Count:" + count);
			}
		}
		/*class Inner1 extends InnerClass{
			
		}*/
		
		InnerClass class1=new InnerClass();
		class1.show();
		
	}

}
