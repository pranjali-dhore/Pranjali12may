package org.cap;

public class Employee {
	
	private int empId;
	private String empName;
	
	public Employee(){}
	
	public Employee(int empId, String empName) {
	
		this.empId = empId;
		this.empName = empName;
	}

	
	/*@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empId != other.empId)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		return true;
	}
	
	*/
	
	
	
	
	/*@Override
	public boolean equals(Object obj){
		
		Employee emp=(Employee)obj;
		
		if(this==null||emp==null)
			return false;
		else{
			
			if(this==emp)
				return true;
			else{
				if(this.empId==emp.empId){
					if(this.empName.equals(emp.empName))
						return true;
					else
						return false;
				}
				else
					return false;
			}
		}
	}*/
	
	

}
