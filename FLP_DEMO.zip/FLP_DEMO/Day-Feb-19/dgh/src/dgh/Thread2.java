package dgh;

public class Thread2 implements Runnable {
	public void run() {
		System.out.print("run");
		throw new RuntimeException("Prob");
	}
}

	



	


