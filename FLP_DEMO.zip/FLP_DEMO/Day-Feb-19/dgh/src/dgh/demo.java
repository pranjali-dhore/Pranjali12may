package dgh;

public class demo {
		     
			        	public static void main(String[] args) 
			        	{
			        	
			        			Thread t= new Thread(new Thread2());
			                       t.start();
			                      System.out.print("End");
			        }



}
