package org.cap.demo;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	
	public Employee getEmployee(){
		Employee employee=new Employee();
		
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		int empid;
		
		do{
		System.out.println("Enter Employee Id:");
		empid=sc.nextInt();
		flag=Validation.isValidEmpId(empid);
			if(!flag)
				System.out.println("Please enter Valid EmployeeId!");
			
		}while(!flag);
		employee.setEmpId(empid);
		//employee.setEmpId(sc.nextInt());
		
		
		String edob;
		do{
			System.out.println("Enter Employee Date of Birth[dd-MMM-yyyy]:");
			edob=sc.next();
			flag=Validation.isValidDate(edob);
				if(!flag)
					System.out.println("Please enter Valid Date!");
				
		}while(!flag);
		Date empDob=new Date(edob);
		employee.setDob(empDob);
		
		
		return employee;
		
	}

}
