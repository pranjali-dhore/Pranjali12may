package org.cap.demo;

public class Validation {
	
	public static boolean isValidEmpId(int empId){
		boolean flag=false;
		
		if(empId>=1000 && empId<=9999)
			flag=true;
			
			return flag;
	}

	
	public static boolean isValidDate(String myDate){
		return myDate.matches("[123]\\d{1}-(jan|feb|mar|apr|jun|jul|aug|sep|oct|dec)-"
				+ "[12][890]\\d{2}");
	}
	
	
	
	
}
