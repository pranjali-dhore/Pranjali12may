package flp.capgemini.Map.Assignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class AccounDAO {
	
//	UserInteraction intr=new UserInteraction();
	
	
    HashMap<Long, Account> maps=new HashMap<>();
    
    public void saveAccount(long key,Account account)
    {
    	maps.put(key, account);
    }
    
    public void listAllAccount()
    {
    	
    	
    	Set<Long> set=maps.keySet();
    	Iterator<Long> itr=set.iterator();
    	while(itr.hasNext())
    	{
    		Long key=itr.next();
    		System.out.println(key+"-"+maps.get(key).toString());
    	}

    	
    }
    
    
}
