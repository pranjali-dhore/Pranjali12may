package flp.capgemini.Map.Assignment;

import java.util.Scanner;

public class BootClass {
	public static void main(String[] args) {
	/*double m=Math.random();*/
	/*for(int i=0;i<3;i++)
	{
		double m=Math.random();
	System.out.println((int)(m*1000000));
	}*/
		Account acc1=null;
		AccounDAO accd=new AccounDAO();
		UserInteraction intr=new UserInteraction();
		Scanner sc=new Scanner(System.in);
		int option1,option2;
		String choice1;
	    long accountId;
		
		do{
			System.out.println("1.Create Account");
			System.out.println("2.Delete Account");
			System.out.println("3.ListAll Account");
			System.out.println("4.Search Account");
			System.out.println("5.Update Account");
			System.out.println("6.Sort Account");
			System.out.println("Enter your option:");
			option1=sc.nextInt();
			if(option1==1)
			{
				 acc1=new Account();
				acc1=intr.getAccountDetails();
				 accountId=intr.generateAccounId();
				System.out.println(accountId);
				 
				accd.saveAccount(accountId,acc1);
				
			}
			if(option1==3)
			{
				accd.listAllAccount();
			}
			
			System.out.println("Wish to continue(y/Y)");
			choice1=sc.next();
		}while(choice1.charAt(0)=='y'||choice1.charAt(0)=='Y');
		
		
	}

}
