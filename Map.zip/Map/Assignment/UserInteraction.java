package flp.capgemini.Map.Assignment;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {

	public Account getAccountDetails()
	{
		Scanner sc=new Scanner(System.in);
		Account acc=new Account();
		
		//Name
		System.out.println("Enter name Of Account Holder:");
		String accname=sc.next();
		acc.setName(accname);
		
		//OpeningDate
		System.out.println("Enter the opening Date[dd-mmm-yyyy]:");
		String date1=sc.next();
		Date d1=new Date(date1);
		acc.setOpenDate(d1);
		
		//AccType
		System.out.println("Enter Account Type:");
		String accType=sc.next();
		acc.setAccType(accType);
		
		//Balance
		System.out.println("Enter balance:");
		double bal=sc.nextDouble();
		acc.setAccount_balance(bal);
		
		
		return acc;
	}
	
	
	public  long generateAccounId()
	{
		long d=(long)(Math.random()*100000);
	
		return d;
	}
}
