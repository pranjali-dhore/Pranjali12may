function validateTitle(){
	var flag=true;
	var title= CreateFilm1.title.value;
	 
	
//	var duration=CreateFilm.duration.value;
//	var cost =CreateFilm.cost.value;
//	var rating = CreateFilm.rating.value;
//	
//	var actor = CreateFilm.actor.value;
//	var oriLang= CreateFilm.oriLang.value;
//	var otherlang=CreateFilm.otherlang.value;
//	var category =CreateFilm.category.value;

	var letters = /^[A-Za-z]+$/;  
	if(title.match(letters))  
	{  
		document.getElementById("titleerr").innerHTML="";
		return true;  
	}  
	else  
	{  
		document.getElementById("titleerr").innerHTML="*Title should Alphabet and It should Not be Null"; 
		title.focus();  
		return false;  
	}  

	return flag;
}

function validateDesc(){
	desc = CreateFilm1.desc.value;

	var letters = /^[A-Za-z]+$/;  
	if(desc.match(letters))  
	{  
		document.getElementById("descerr").innerHTML="";
		return true;  
	}  
	else  
	{  
		document.getElementById("descerr").innerHTML="*Desciption should contain Alphabet and It should Not be Null"; 
		desc.focus();  
		return false;  
	}  
}


function validateRentalDuration()
{
	var releasedate =  CreateFilm1.releasedate.value;
	var duration =CreateFilm1.rentalduration.value;
	
	if(renDuration>relDate)
	{
	document.getElementById("Rentalerr").innerHTML="";
		return true;  
	}	else  
	{  
		document.getElementById("Rentalerr").innerHTML="*Rental Duration should be greater than Realease date "; 
		/*duration.focus();  */
		return false;  
	}
	
}
	function validateLength()
	{
		var length = CreateFilm1.duration.value;
		if( length>0 && length<1000)
			{
			document.getElementById("Durerr").innerHTML="";
			return true;  
		}
		else  
		{  
			document.getElementById("Durerr").innerHTML="* 1. Duration should Numeric Value between[1-1000]"; 
			length.focus();  
			return false;  
			}
		
	}
	
	function ValidateReplacementCost() {
		var cost =CreateFilm1.cost.value;
		if( cost>1000)
			{
			document.getElementById("ReplacementCost").innerHTML="";
			return true;  
		}
		else  
		{  
			document.getElementById("ReplacementCost").innerHTML="* ReplacementCost should be greater than 1000"; 
			cost.focus();  
			return false;  
			}
		
	}
	function ValidateSpecialFeature() {
		var features =CreateFilm1.features.value;
		var letters = /^[A-Za-z]+$/;  
		if(features.match(letters))  
		{  
			document.getElementById("featureeerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("featureeerr").innerHTML="*Special feature should Not be Null"; 
			features.focus();  
			return false;  
		}  

		return flag;
		
	}


