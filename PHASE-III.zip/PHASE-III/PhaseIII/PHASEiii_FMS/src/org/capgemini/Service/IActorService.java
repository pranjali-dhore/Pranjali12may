package org.capgemini.Service;

import java.util.List;

import org.capgemini.pOJO.Actor;

public interface IActorService {
	public List<Actor> addActor();

	List<Actor> getActorList();

}
