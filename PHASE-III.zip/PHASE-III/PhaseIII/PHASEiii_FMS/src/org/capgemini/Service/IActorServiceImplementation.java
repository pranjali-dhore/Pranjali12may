package org.capgemini.Service;

import java.util.List;

import org.capgemini.DAO.IActorDao;
import org.capgemini.DAO.IActorImpl;
import org.capgemini.pOJO.Actor;

public class IActorServiceImplementation implements IActorService{
	IActorDao actorDao=new IActorImpl();
	@Override
	public List<Actor> addActor() {
		
		return actorDao.addActor();
	}

	@Override
	public List<Actor> getActorList() {
		
		return actorDao.getActorList();
	}

}
