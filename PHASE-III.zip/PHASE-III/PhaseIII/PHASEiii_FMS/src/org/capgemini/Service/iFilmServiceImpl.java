package org.capgemini.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.capgemini.DAO.IActorDao;
import org.capgemini.DAO.IActorImpl;
import org.capgemini.DAO.IFilmDao;
import org.capgemini.DAO.IFilmDaoIml;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public class iFilmServiceImpl  implements IFilmService{
	IFilmDao filmDao=new IFilmDaoIml();
	@Override
	public List<Language> getLanguage() {
		
		return filmDao.getOriginalLanguage() ;
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	@Override
	public void addFilm(Film film) {

	    //film.setFilm_id(film_id);
		filmDao.addFilm(film);
		
	}


	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}

	@Override
	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilm(filmid);
	}


	public ArrayList<Film> searchFilm(Film film) {
		
		return filmDao.searchFilm(film);
	}

	public int updateFilm(int id, Film film) 
	{
		return filmDao.updateFilm(id, film);
	}

	public Film getSearchFilmByID(int id) {
		return filmDao.getSearchFilmByID(id);
	}

	
	

}
