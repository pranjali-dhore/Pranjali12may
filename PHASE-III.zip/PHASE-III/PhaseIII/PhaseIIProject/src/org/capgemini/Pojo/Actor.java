package org.capgemini.Pojo;

public class Actor {
	private int Actor_Id;
	private String Actor_FirstName;
	private String Actor_LastName;
	private int Film_id;
	public Actor(){}
	public Actor(int actor_Id, String actor_FirstName, String actor_LastName, int film_id) {
		super();
		Actor_Id = actor_Id;
		Actor_FirstName = actor_FirstName;
		Actor_LastName = actor_LastName;
		Film_id = film_id;
	}
	public int getActor_Id() {
		return Actor_Id;
	}
	public void setActor_Id(int actor_Id) {
		Actor_Id = actor_Id;
	}
	public String getActor_FirstName() {
		return Actor_FirstName;
	}
	public void setActor_FirstName(String actor_FirstName) {
		Actor_FirstName = actor_FirstName;
	}
	public String getActor_LastName() {
		return Actor_LastName;
	}
	public void setActor_LastName(String actor_LastName) {
		Actor_LastName = actor_LastName;
	}
	public int getFilm_id() {
		return Film_id;
	}
	public void setFilm_id(int film_id) {
		Film_id = film_id;
	}
	@Override
	public String toString() {
		return "Actor [Actor_Id=" + Actor_Id + ", Actor_FirstName=" + Actor_FirstName + ", Actor_LastName="
				+ Actor_LastName + ", Film_id=" + Film_id + "]";
	}
	
}
