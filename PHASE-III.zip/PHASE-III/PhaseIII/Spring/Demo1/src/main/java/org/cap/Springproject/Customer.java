package org.cap.Springproject;

public class Customer {

	private int cust_id;
	private String name;
	private Adress add;
	public Customer(){}
	
	public Customer(int cust_id, String name, Adress add) {
		super();
		this.cust_id = cust_id;
		this.name = name;
		this.add = add;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Adress getAdd() {
		return add;
	}

	public void setAdd(Adress add) {
		this.add = add;
	}

	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", name=" + name + ", add=" + add + "]";
	}
	
	
}
