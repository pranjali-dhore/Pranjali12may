package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.Service.iFilmServiceImpl;
import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

/**
 * Servlet implementation class Updateservlet2
 */
public class Updateservlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updateservlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
             PrintWriter out=response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("film_id"));
		  iFilmServiceImpl filmService=new iFilmServiceImpl();
		  Film film=new Film();
		  
		  film.setTittle(request.getParameter("title"));
		  film.setDescription(request.getParameter("desc"));
		  film.setReleaseYear(new Date(request.getParameter("release")));
		  film.setSpecialFeature(request.getParameter("spec"));
		  film.setLength(Integer.parseInt(request.getParameter("length")));
		  film.setReplacementCost(Double.parseDouble(request.getParameter("cost")));
		  film.setRatings(Integer.parseInt(request.getParameter("rating")));
		  film.setRetalDuration(new Date(request.getParameter("rentD")));
		  
		  Language lang=new Language();
		  lang.setLanguage_id(Integer.parseInt(request.getParameter("orgLang")));
		  film.setOriginalLanguage(lang);
		  
		  
		  Category category=new Category();
		  category.setCategory_id(Integer.parseInt(request.getParameter("category")));
		  film.setCategory(category);
		  
		
		  
		  String [] actors=request.getParameterValues("actor");
		  List<Actor> actor1=new ArrayList<>();
		  
		  for(String str:actors){
			  Actor act=new Actor();
			  act.setActor_Id(Integer.parseInt(str));
			  actor1.add(act);
			  
		  }
		   film.setActors(actor1);
		   
		   
		   String [] lang1=request.getParameterValues("othrlang");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguage_id(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		  film.setLanguages(langs);
		   System.out.println("update");
		   System.out.println(id);
		   System.out.println(film);
		   
		  int c= filmService.updateFilm(id,film);
		  if(c>0)
			
			  response.sendRedirect("UpdatepageServlet");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
