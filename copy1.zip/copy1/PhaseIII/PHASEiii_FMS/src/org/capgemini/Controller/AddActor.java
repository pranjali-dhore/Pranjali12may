package org.capgemini.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.DAO.IActorImpl;
import org.capgemini.pOJO.Actor;

/**
 * Servlet implementation class AddActor
 */
public class AddActor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddActor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Actor actor = new Actor();
		IActorImpl actorService = new IActorImpl();
		actor.setActor_FirstName(request.getParameter("FirstName"));
		actor.setActor_LastName(request.getParameter("LastName"));
		System.out.println("AddActor"+actor);
		actorService.addActor(actor);
	}

}
