package org.capgemini.DAO;

import java.util.List;

import org.capgemini.pOJO.Actor;

public interface IActorDao {
	public List<Actor> addActor();

	List<Actor> getActorList();
	public void addActor(Actor actor);
}
