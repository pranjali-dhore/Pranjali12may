package org.capgemini.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capgemini.pOJO.Actor;

public class IActorImpl implements IActorDao{

	@Override
	public List<Actor> addActor() {
	
		 return getActorList();
	}

	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		IFilmDaoIml filmDao=new IFilmDaoIml();
		Connection con=filmDao.getConnection();
		
		String sql="select * from ACTOR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setActor_FirstName(rs.getString(2));
				actor1.setActor_LastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	
		
	}
	public void addActor(Actor actor) {
		IActorImpl actorimp = new IActorImpl();
		IFilmDaoIml filmdao=new IFilmDaoIml();
		Connection con=filmdao.getConnection();	
		String sql="Insert into actor ( firstName,lastName)"+" values (?,?)";
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(sql);	
			pst.setString(1, actor.getActor_FirstName());
			pst.setString(2,actor.getActor_LastName());
			System.out.println(actor);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(actor);
	}


}
