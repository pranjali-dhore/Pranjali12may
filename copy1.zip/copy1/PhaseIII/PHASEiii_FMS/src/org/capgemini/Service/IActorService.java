package org.capgemini.Service;

import java.util.List;

import org.capgemini.pOJO.Actor;

public interface IActorService {
	public List<Actor> addActor();
	public void addActor(Actor actor);
	List<Actor> getActorList();

}
