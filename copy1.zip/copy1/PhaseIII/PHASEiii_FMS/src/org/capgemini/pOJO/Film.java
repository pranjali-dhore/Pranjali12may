package org.capgemini.pOJO;

import java.util.Date;
import java.util.List;

import com.sun.org.apache.bcel.internal.generic.LNEG;


public class Film {
	private int Film_id;
	private String tittle;
	private String description;
	private Date releaseYear;
	private List<Language> languages;
	private Language originalLanguage;
	private Date retalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String SpecialFeature;
	private List<Actor> actors;
	private Category category;
	public Film(){}
	public Film(int film_id, String tittle, String description, Date releaseYear, List<Language> languages,
			Language originalLanguage, Date retalDuration, int length, double replacementCost, int ratings,
			String specialFeature, List<Actor> actors, Category category) {
		super();
		Film_id = film_id;
		this.tittle = tittle;
		this.description = description;
		this.releaseYear = releaseYear;
		this.languages = languages;
		this.originalLanguage = originalLanguage;
		this.retalDuration = retalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		SpecialFeature = specialFeature;
		this.actors = actors;
		this.category = category;
	}
	public int getFilm_id() {
		return Film_id;
	}
	public void setFilm_id(int film_id) {
		Film_id = film_id;
	}
	public String getTittle() {
		return tittle;
	}
	public void setTittle(String tittle) {
		this.tittle = tittle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public List<Language> getLanguages() {
		return languages;
	}
	public void setLanguages(List<Language> languages) {
		this.languages = languages;
	}
	public Language getOriginalLanguage() {
		return originalLanguage;
	}
	public void setOriginalLanguage(Language originalLanguage) {
		this.originalLanguage = originalLanguage;
	}
	public Date getRetalDuration() {
		return retalDuration;
	}
	public void setRetalDuration(Date retalDuration) {
		this.retalDuration = retalDuration;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public double getReplacementCost() {
		return replacementCost;
	}
	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public String getSpecialFeature() {
		return SpecialFeature;
	}
	public void setSpecialFeature(String specialFeature) {
		SpecialFeature = specialFeature;
	}
	public List<Actor> getActors() {
		return actors;
	}
	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Film [Film_id=" + Film_id + ", tittle=" + tittle + ", description=" + description + ", releaseYear="
				+ releaseYear + ", languages=" + languages + ", originalLanguage=" + originalLanguage
				+ ", retalDuration=" + retalDuration + ", length=" + length + ", replacementCost=" + replacementCost
				+ ", ratings=" + ratings + ", SpecialFeature=" + SpecialFeature + ", actors=" + actors + ", category="
				+ category + "]";
	}
	
	
	
	
	
	
}
