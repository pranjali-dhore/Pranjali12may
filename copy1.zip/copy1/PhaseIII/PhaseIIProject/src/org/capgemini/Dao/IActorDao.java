package org.capgemini.Dao;

import java.util.List;

import org.capgemini.Pojo.Actor;

public interface IActorDao {

	public List<Actor>addActor();

	List<Actor> getActorList();
}
