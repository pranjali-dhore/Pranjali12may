USE phaseiiidatabase
CREATE TABLE ACTOR(
actorID INT PRIMARY KEY AUTO_INCREMENT,
firstName VARCHAR(25),
lastName VARCHAR(25));

INSERT INTO ACTOR VALUES(1, "Salman", "Khan");
INSERT INTO ACTOR VALUES(2, "Shahrukh", "Khan");
INSERT INTO ACTOR VALUES(3, "Hritik", "Roshan");
INSERT INTO ACTOR VALUES(4, "Salman", "Khan");
INSERT INTO ACTOR VALUES(5, "Kangna", "Ranaut");
INSERT INTO ACTOR VALUES(6, "Alia", "Bhat");
INSERT INTO ACTOR VALUES(7,"Shaharukh", "Khan");
INSERT INTO ACTOR VALUES(8, "Kareena", "Kapoor");
INSERT INTO ACTOR VALUES(9,"Aishwarya", "Ray");
INSERT INTO ACTOR VALUES(10,"Deepika", "Padukon");

SELECT * FROM ACTOR 
*----------------------------------*


CREATE TABLE CATEGORY(categoryID INT PRIMARY KEY,
NAME VARCHAR(25));

DESC CATEGORY;
INSERT INTO CATEGORY VALUES(1, "Action");
INSERT INTO CATEGORY VALUES(2, "Horrer");
INSERT INTO CATEGORY VALUES(3, "Comic");
INSERT INTO CATEGORY VALUES(4, "Romance");
INSERT INTO CATEGORY VALUES(5, "Science Fiction");
INSERT INTO CATEGORY VALUES(6, "Suspence");
SELECT * FROM CATEGORY

***_______________________***

CREATE TABLE LANGUAGE(languageID INT PRIMARY KEY,
NAME VARCHAR(25));

DESC LANGUAGE;

INSERT INTO LANGUAGE VALUES(1, "English");
INSERT INTO LANGUAGE VALUES(2, "Hindi");
INSERT INTO LANGUAGE VALUES(3, "Marathi");
INSERT INTO LANGUAGE VALUES(4, "Telegu");
INSERT INTO LANGUAGE VALUES(5, "Kananta");
INSERT INTO LANGUAGE VALUES(6, "Tamil");
INSERT INTO LANGUAGE VALUES(7, "Malayalam");


USE phaseiiidatabase

CREATE TABLE film(filmid INT PRIMARY KEY AUTO_INCREMENT, 
title VARCHAR(100) NOT NULL,
description VARCHAR(100),
releaseYear DATE NOT NULL,
rentalDuration DATE NOT NULL,
LENGTH INT NOT NULL,
originalLanguage INT REFERENCES LANGUAGE(languageID),
replacementCost DOUBLE NOT NULL,
ratings INT NOT NULL,
specialFeatures VARCHAR(100),
category INT REFERENCES CATEGORY(categoryID));

title ,description,releaseYear,rentalDuration,LENGTH,originalLanguage ,replacementCost,
ratings ,specialFeatures,category

