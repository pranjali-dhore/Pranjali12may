function validateField(){
	var flag=true;
	var uname=form1.uname.value;
	
	var upwd=form1.upwd.value;
	
		if(uname==""||uname==null)
		{
		document.getElementById("unameErr").innerHTML="*Please enter UserName";
		flag=false;
		}else
			document.getElementById("unameErr").innerHTML="";
	
		if(upwd==""||upwd==null)
		{
		document.getElementById("upwdErr").innerHTML="*Please enter Password";
		flag=false;
		}else
			document.getElementById("upwdErr").innerHTML="";
	
	
	return flag;
}