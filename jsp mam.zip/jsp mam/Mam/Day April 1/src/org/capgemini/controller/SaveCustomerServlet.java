package org.capgemini.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class SaveCustomerServlet
 */
public class SaveCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService=new LoginServiceImpl();
		
		Customer customer=new Customer();
		
		customer.setFirstName(request.getParameter("fname"));
		customer.setLastName(request.getParameter("lname"));
		customer.setAddress(request.getParameter("address"));
		customer.setGender(request.getParameter("gender"));
		
		
		
		double regfees=Double.parseDouble(request.getParameter("regfees"));
		customer.setRegFees(regfees);
		
		String dob=request.getParameter("regdate");
		Date regdate=new Date(dob);
		customer.setRegDate(regdate);
		
		String custtype=request.getParameter("custtype");
		customer.setCustType(custtype);
		
		System.out.println(customer);
		
		//Persist customer Object into DataBase
		loginService.saveCustomer(customer);
		
		//response.sendRedirect("SaveCustomerServlet");
		request.getRequestDispatcher("pages/Customer.html").forward(request, response);
		
	}

}













