package org.capgemini.service;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public interface LoginService {
	
	public boolean isValidLogin(LoginUser loginUser);
	public void saveCustomer(Customer customer);

}
