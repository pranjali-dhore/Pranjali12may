package org.capgemini.service;

import org.capgemini.dao.LoginDao;
import org.capgemini.dao.LoginDaoImpl;
import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public class LoginServiceImpl implements LoginService {
	
	
	private LoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveCustomer(Customer customer) {
		loginDao.saveCustomer(customer);
	}

}
