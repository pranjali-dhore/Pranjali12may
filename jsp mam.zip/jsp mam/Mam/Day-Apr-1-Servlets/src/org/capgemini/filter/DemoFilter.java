package org.capgemini.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class DemoFilter
 */
public class DemoFilter implements Filter {

   
	public void destroy() {
		System.out.println("Filter init Destroy Method");
	}

	
	public void doFilter(ServletRequest request, 
			ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		//Request Filter
		System.out.println("Request Filter");
		
		HttpServletRequest req=(HttpServletRequest)request;
		String uname=req.getParameter("uname");
		String upwd=req.getParameter("upwd");
		
		System.out.println("Name :" + uname);
		System.out.println("Pasword :" + upwd);
		
		chain.doFilter(request, response);
		
		System.out.println("Response Filter");
		//Response Filter
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("Filter init Method");
	}

}
