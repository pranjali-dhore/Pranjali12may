package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Employee;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class DisplayEmpServlet
 */
public class DisplayEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		LoginService loginService=new LoginServiceImpl();
		String empId=request.getParameter("empId");
		
		Employee emp=loginService.searchEmployee(Integer.parseInt(empId));
		
		PrintWriter out=response.getWriter();
		out.println("<h1 align='center'>Employee Details</h1>");
		out.println("<b>Employee Id: </b>" + emp.getEmpId() +"<br><br>" );
		out.println("<b>Employee FirstName: </b>" + emp.getFirstName() +"<br><br>" );
		out.println("<b>Employee LastName: </b>" + emp.getLastName() +"<br><br>" );
	
	
	
	}

}
