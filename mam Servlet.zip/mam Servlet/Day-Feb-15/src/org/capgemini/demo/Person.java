package org.capgemini.demo;

import java.util.Scanner;

public class Person {
	
	private int personId;
	private String personName;
	private String address;
	private int c,cpp,java;
	private float total,average;
	
	
	
	public void getPersonDetails(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Address:");
		address=sc.nextLine();
		
		System.out.println("Enter PersonId:");
		personId=sc.nextInt();
		System.out.println("Enter PersonName:");
		personName=sc.next();
		
		
		
		System.out.println("Enter c,cpp,JAva:");
		c=sc.nextInt();
		cpp=sc.nextInt();
		java=sc.nextInt();
		
		total=c+cpp+java;
		
	}
	
	private float calculateAverage(){
		return (float)(total)/3;
	}
	
	public void printPersonDetails(){
		System.out.println("Person Id: " + personId);
		System.out.println("Name:" + personName);
		System.out.println("Address: " +address);
		System.out.println("C Mark:" + c);
		System.out.println("CPP Mark:" + cpp);
		System.out.println("JAVA Mark:" + java);
		System.out.println("Total :" + total);
		//System.out.println("Average: " + calculateAverage());
		average=calculateAverage();
		System.out.println("Average: "+average);
	}
	
	

}
