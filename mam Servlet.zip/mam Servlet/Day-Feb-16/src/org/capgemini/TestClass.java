package org.capgemini;

public class TestClass {

	public static void main(String[] args) {
		
		//Object
		Employee emp=new Employee();
		emp.empId=123;
		emp.firstName="Tom";
		emp.lastName="Jerry";
		
		//Employee.compId=1991;
		emp.compId=1991;
		
		//object
		Employee emp1=new Employee();
		emp1.empId=111;
		emp1.firstName="Jack";
		emp1.lastName="Thomson";
		
		emp.printEmployee();
		emp1.printEmployee();
		
		Employee.myMethod();

	}

}
