package flp.cap.demo;

import java.util.Scanner;

public class WeeklySalaryEmployee  extends Employee{
	
	float no_of_hours;
	float wages_per_hour;
	
	
	@Override
	public double calculateSalary() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter no_of_hours");
		no_of_hours=scanner.nextFloat();
		
		System.out.println("Enter wages_per_hour");
		wages_per_hour=scanner.nextFloat();
		
		return wages_per_hour*no_of_hours;
	}

}
