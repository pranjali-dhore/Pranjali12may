package org.cap.bookstore;

public interface BookDao {
	
	public void saveBook(Book book);
	public void listAllBooks();
	
	
	
	public Book findBook(int bookId);
	public void deleteBook(int bookId);
	

}
