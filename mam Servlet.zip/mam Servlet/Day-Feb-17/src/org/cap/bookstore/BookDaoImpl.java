package org.cap.bookstore;

public class BookDaoImpl implements BookDao{
	
	Book[] books;
	int index;
	
	public  BookDaoImpl() {
		books=new Book[50];
	}

	@Override
	public void saveBook(Book book) {
		books[index]=book;
		index++;
		
	}

	@Override
	public void listAllBooks() {
		
		System.out.println("BookId\tBookName\tAuthor\tPublisher\tPrice");
		
		for(int i=0;i<index;i++)
			books[i].showBookDetails();
			
		
	}

	@Override
	public Book findBook(int bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBook(int bookId) {
		// TODO Auto-generated method stub
		
	}

}
