package org.capgemini;

public  class  Person {
	
	protected int personId;
	String personName;
	
	public void show(){
		System.out.println("Person Class Show Method");
	}
	
	public static void myMethod(){
		System.out.println("Person Class Static Method");
	}

}
