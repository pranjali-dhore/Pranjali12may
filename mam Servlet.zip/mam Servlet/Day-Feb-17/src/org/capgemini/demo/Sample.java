package org.capgemini.demo;

public class Sample {
	public static void main(String[] args){
		MyChild class1=new MyChild(100,"Tom");
		//MyChild class1=new MyChild();
		//class1.print();
	}
	
}
