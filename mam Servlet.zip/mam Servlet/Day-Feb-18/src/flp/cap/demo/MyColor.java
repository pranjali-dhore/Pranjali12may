package flp.cap.demo;

public enum MyColor {
	
	RED(0,255), GREEN(100,200),BLUE(256,500);
	
	private int minValue;
	private int maxValue;
	
	MyColor(int minValue,int maxValue){
		this.minValue=minValue;
		this.maxValue=maxValue;
	}
	
	public int getMinValue(){
		return minValue;
	}
	
	public int getMaxValue(){
		return maxValue;
	}
	

}
