package flp.cap.nestedclass;

public interface Graphics {

	public void move();
	
	public interface Color{
		public void myColor();
	}
}
