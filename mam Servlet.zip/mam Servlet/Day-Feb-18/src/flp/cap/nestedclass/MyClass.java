package flp.cap.nestedclass;

public class MyClass {
	
	public void show(){
		System.out.println("MyClass Show Method");
	}

}
