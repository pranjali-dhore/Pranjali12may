package flp.cap.nestedclass;

public class NonStaticClass {
	
	int index1;
	
	static int index=19;
	
	
	static class MyStaticClass{
		int num=100;
		static int count=50;
		
		public void non_Static_Method(){
			System.out.println("Index:" + index);
			System.out.println("Num :" + num);
			System.out.println("Count:" + count);
			System.out.println("non-Static method");
		}
		
		public static void static_Method(){
			int num=12;
			System.out.println("Index:" + index);
			System.out.println("Static method");
			System.out.println("Count:" + count);
			System.out.println("Num :" + num);
		}
		
	}

}
