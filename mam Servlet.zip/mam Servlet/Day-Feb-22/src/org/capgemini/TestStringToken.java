package org.capgemini;

import java.util.StringTokenizer;

public class TestStringToken {
	
	public static void main(String[] args){
		String myStr="  Hello, we are lear,ning Java!";
		StringTokenizer tokenizer=new StringTokenizer(myStr,"[ ,]");
		
		System.out.println(tokenizer.countTokens());
		
		while(tokenizer.hasMoreTokens()){
		System.out.println(tokenizer.nextToken());
		}
		
	}

}
