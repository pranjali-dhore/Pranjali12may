package org.capgemini.exception.demo;

public class ExceptionDemo {

	public static void main(String[] args){
		
		int num2=0;
		String num1="10s";
		int ans=0;
		try{
			int n2=Integer.parseInt(num1);
			
			try{
			ans=n2/num2;
			
			System.out.println("Answer :" + ans);
			//System.exit(10);
			}catch(NumberFormatException e){
				e.printStackTrace();
			}
		}catch(ArithmeticException ex){//jdk 1.7
			System.out.println(ex.getMessage());
		}finally{
			System.out.println("Finally Executed");
		}
	
		System.out.println("Program Completed");
		
	}
}
