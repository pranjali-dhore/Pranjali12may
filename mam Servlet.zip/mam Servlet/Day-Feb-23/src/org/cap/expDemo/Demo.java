package org.cap.expDemo;

import java.io.IOException;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new WeeklyEmployee();
		
		try{
			
			//calling method
		double bonus=employee.findBonus();
		System.out.println("Bonus:" + bonus);
		}catch(NumberFormatException|ArithmeticException e){
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Program Completed");

	}

}
