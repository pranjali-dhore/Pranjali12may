package org.cap.expDemo;

import java.io.IOException;

public class Employee {
	
	public double findBonus() throws IOException,ArithmeticException,NumberFormatException{
		String val="1000s",val2="500";
		
		return Integer.parseInt(val)/Integer.parseInt(val2);
	}

}
