package org.cap.expDemo;

public class InvalidAgeException extends Exception{

	public InvalidAgeException(String msg){
		super(msg);
	}
	
	/*@Override
	public String getMessage(){
		return "Invalid Age! Age should be greater than 18.";
	}*/
	
}
