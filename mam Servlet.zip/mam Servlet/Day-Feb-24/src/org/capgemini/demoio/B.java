package org.capgemini.demoio;

public class B extends A{
	//int i=Math.round(3.5f);
	
	
	
	public void print(B b){
		System.out.println("B");
	}
}