package org.capgemini.demoio;

public class C  extends B{
	public static void main(String[] arg){

		A a=new A();
		
		B b=new B();
		
		C c=new C();
		
		c.print(b);
		
		c.print(a);
		
		c.print(c);
		
		String s1=new String("ABC");
		String s2=new String("PQR");
		
		String s3=s1+s2;
		
		System.out.println(s3);
		
	}
	
	
	public void print(C c){
		System.out.println("C");
	}
}
