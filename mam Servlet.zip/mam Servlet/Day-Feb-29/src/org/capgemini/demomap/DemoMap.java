package org.capgemini.demomap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class DemoMap {

	public static void main(String[] args) {
		
//		Map<Integer, String> maps=new HashMap<>();
		//HashMap<Integer, String> maps=new HashMap<>();
		//LinkedHashMap<Integer, String> maps=new LinkedHashMap<>();
		//Hashtable<Integer, String> maps=new Hashtable<>();
		TreeMap<Integer, String> maps=new TreeMap<>();
		
		maps.put(1, "Tom");
		maps.put(2, "Sam");
		maps.put(3, "Jessie");
		maps.put(1, "Tom");
		maps.put(11, "Tom");
		maps.put(1, "Jack");
		maps.put(78, "Sam");
		maps.put(34, null);
		maps.put(12,"kamal");
		
		System.out.println(maps);
		
		Collection<String> values= maps.values();

		System.out.println(values);
		System.out.println(maps);
		/*Set<Integer> keys=maps.keySet();
		//System.out.println(keys);
		
		Iterator<Integer> it= keys.iterator();
		while(it.hasNext()){
			Integer key=it.next();
			
			System.out.println(key + " - " + maps.get(key));
		}*/
	}

}
