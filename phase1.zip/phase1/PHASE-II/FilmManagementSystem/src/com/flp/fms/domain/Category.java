package com.flp.fms.domain;

public class Category {
	//Private fields
private int category_Id;
private String Category_Name;
//No Arguments constructor
public Category() {
}
//Parameterized constructor
public Category(int category_Id, String category_Name) {
	super();
	this.category_Id = category_Id;
	Category_Name = category_Name;
	
}
//Setters and Getters
public int getCategory_Id() {
	return category_Id;
}
public void setCategory_Id(int category_Id) {
	this.category_Id = category_Id;
}
public String getCategory_Name() {
	return Category_Name;
}
public void setCategory_Name(String category_Name) {
	Category_Name = category_Name;
}

@Override
public String toString() {
	return "Category [category_Id=" + category_Id + ", Category_Name=" + Category_Name +  "]";
}
}
