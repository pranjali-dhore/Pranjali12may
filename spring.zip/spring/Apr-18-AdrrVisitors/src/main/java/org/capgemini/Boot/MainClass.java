package org.capgemini.Boot;

import org.capgemini.Dao.VisitorDaoImpl;
import org.capgemini.pojo.Address;
import org.capgemini.pojo.Visitors;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcBeans.xml");

		VisitorDaoImpl visitorDao=(VisitorDaoImpl) context.getBean("jdbcTemp");
		
		Address addr=new Address(1, 123, "abc", "Pune", "MAHA");
		Visitors visitor=new Visitors(145, "John", addr);
		
		//visitorDao.createVisitor(visitor);
		
		
		//visitorDao.deleteEmployee(visitor.getVisitorId(),visitor.getVisitorAddress().getAddrId());
		
		Address addr1=new Address(1, 789, "XYZ", "Mumbai", "MAHA");
		Visitors visitor1=new Visitors(145, "Jerry", addr1);
		visitorDao.updateVisitor(visitor1);
		
	}

}
 