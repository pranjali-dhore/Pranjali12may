package org.capgemini.Dao;

import javax.sql.DataSource;

import org.capgemini.pojo.Visitors;

public interface VisitorDao {
	public void setDataSource(DataSource dataSource);
	public void createVisitor(Visitors visitor);
	public void deleteEmployee(int visitorId, int addrid);
	public void updateVisitor(Visitors visitor1);


}
