package org.capgemini.Dao;

import javax.sql.DataSource;

import org.capgemini.pojo.Visitors;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mysql.jdbc.util.ResultSetUtil;

public class VisitorDaoImpl implements VisitorDao{

	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public void createVisitor(Visitors visitor) {
		
		
	
				
		String sql="insert into Visitor values(?,?,?)";
		jdbcTemplate.update(sql, new Object[]{visitor.getVisitorId(),visitor.getVisitorName(),visitor.getVisitorAddress().getAddrId()
			});
		

		String sql1="insert into Address values(?,?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[]{visitor.getVisitorAddress().getAddrId(),
				visitor.getVisitorAddress().getDoorNo(),visitor.getVisitorAddress().getStreetName(),visitor.getVisitorAddress().getCity(),visitor.getVisitorAddress().getState()});

	}

	public void deleteEmployee(int visitorId, int addrid) {
		
		String sql="delete from Visitor where visitorId=?";
		jdbcTemplate.update(sql,visitorId);
		
		String sql2="delete from Address where addressId=?";
		jdbcTemplate.update(sql2,addrid);
		
		
		
		
		
	}

	public void updateVisitor(Visitors visitor1) {
		
		
		String sql1="update Visitor set visitorName=?";
		jdbcTemplate.update(sql1,visitor1.getVisitorName());
		
		
		String sql2="update Address set doorNo=?,streetName=?,city=? where addressId=?";
		jdbcTemplate.update(sql2,new Object[]{visitor1.getVisitorAddress().getDoorNo(),visitor1.getVisitorAddress().getStreetName(),visitor1.getVisitorAddress().getCity(),visitor1.getVisitorAddress().getAddrId()});
		
	}
}
