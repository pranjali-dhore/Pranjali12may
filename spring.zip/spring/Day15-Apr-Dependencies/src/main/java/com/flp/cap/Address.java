package com.flp.cap;

public class Address {
	
	private int doorNo;
	private String strName;
	private String city;
	
	public Address(){}
	public Address(int doorNo, String strName, String city) {
		super();
		this.doorNo = doorNo;
		this.strName = strName;
		this.city = city;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStrName() {
		return strName;
	}
	public void setStrName(String strName) {
		this.strName = strName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", strName=" + strName + ", city=" + city + "]";
	}
	
	
	

}
