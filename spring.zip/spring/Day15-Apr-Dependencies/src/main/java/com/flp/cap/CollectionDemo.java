package com.flp.cap;

import java.util.List;
import java.util.Map;

public class CollectionDemo {
	
	List<String> studName;
	Map<Integer, String> maps;
	
	public CollectionDemo(){}
	public CollectionDemo(List<String> studName, Map<Integer, String> maps) {
		super();
		this.studName = studName;
		this.maps = maps;
	}
	public List<String> getStudName() {
		return studName;
	}
	public void setStudName(List<String> studName) {
		this.studName = studName;
	}
	public Map<Integer, String> getMaps() {
		return maps;
	}
	public void setMaps(Map<Integer, String> maps) {
		this.maps = maps;
	}
	@Override
	public String toString() {
		return "CollectionDemo [studName=" + studName + ", maps=" + maps + "]";
	}
	
	
	
	
	
	

}
