package com.flp.cap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CollectionMain {

	public static void main(String[] args) {


		ApplicationContext context=new ClassPathXmlApplicationContext("Beans1.xml");

		CollectionDemo collDemo=(CollectionDemo) context.getBean("collDemo");
		System.out.println(collDemo);
	}

}
