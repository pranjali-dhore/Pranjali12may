package com.flp.cap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		Customer cust=(Customer) context.getBean("customer");
        BeanPPDemo bpp=(BeanPPDemo) context.getBean("BeanPostPro");
		System.out.println(cust);
		
		
		
	}

}
