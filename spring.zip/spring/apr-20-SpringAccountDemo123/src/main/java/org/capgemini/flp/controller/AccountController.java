package org.capgemini.flp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.catalina.connector.Request;
import org.capgemini.pojo.Account;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountController {
	
	@RequestMapping("/hello")
	public ModelAndView showHello()
	{
		return new ModelAndView("helloPage","msg","Hello World!!");
		
	}
	
	@RequestMapping("/accForm")
	public String showAccForm(Map<String, Object> maps) {
		
		maps.put("account", new Account());
		maps.put("accType", getAccountType());
	
		return "AccountForm";
		
	}
	
	
	@RequestMapping(value="showAccDetails",method=RequestMethod.POST)
	public String showAcoountDetails(@Valid @ModelAttribute("account") Account acc,BindingResult result){
		
		
		if(result.hasErrors())
		{
			return "AccountForm";
		}
		
		else{
		System.out.println(acc);
	    return "showAccount";
		}
		
	}
	
	
	
	public List<String> getAccountType() {
		
		List<String> accountType=new ArrayList<>();
		
		accountType.add("saving");
		accountType.add("Current");
		accountType.add("RD");
		accountType.add("FD");
		
		
		return accountType;
		
	}
	

}
