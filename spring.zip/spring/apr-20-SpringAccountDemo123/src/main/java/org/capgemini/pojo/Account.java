package org.capgemini.pojo;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Account {
	

	@Range(min=15 , max=15,message="*Account numbber should be 15 digits")
	private long accountNo;
	@NotEmpty(message="*Please enter account holder name")
	private String accountName;
	@Past(message="*Date must be past date")
	private Date openDate;
	private String accountType;
	@Range(min=500,max=300000)
	private long amount;
	@Past(message="*Date must be past date")
	private Date dateOfBirth;
	private String gender;
	
	public Account(){}
	
	
	public Account(long accountNo, String accountName, Date openDate, String accountType, long amount, Date dateOfBirth,
			String gender) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.openDate = openDate;
		this.accountType = accountType;
		this.amount = amount;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
	}


	public long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public Date getOpenDate() {
		return openDate;
	}


	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public long getAmount() {
		return amount;
	}


	public void setAmount(long amount) {
		this.amount = amount;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", openDate=" + openDate
				+ ", accountType=" + accountType + ", amount=" + amount + ", dateOfBirth=" + dateOfBirth + ", gender="
				+ gender + "]";
	}
	
	
	
	
	
	
	
	

}
