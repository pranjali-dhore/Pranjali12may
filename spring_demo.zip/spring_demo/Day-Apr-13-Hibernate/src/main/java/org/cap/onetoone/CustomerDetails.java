package org.cap.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CustomerDetails {
	
	@Id
	private int custDetId;
	private String address;
	private String city;
	private String state;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private Customer customer;
	
	public CustomerDetails(){}
	
	public CustomerDetails(int custDetId, String address, String city, String state) {
		super();
		this.custDetId = custDetId;
		this.address = address;
		this.city = city;
		this.state = state;
	}
	
	public CustomerDetails( String address, String city, String state) {
		super();
		
		this.address = address;
		this.city = city;
		this.state = state;
	}
	public int getCustDetId() {
		return custDetId;
	}
	public void setCustDetId(int custDetId) {
		this.custDetId = custDetId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "CustomerDetails [custDetId=" + custDetId + ", address=" + address + ", city=" + city + ", state="
				+ state + "]";
	}
	
	

}
