package org.cap.onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(CustomerDetails.class);
		config.addAnnotatedClass(Customer.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		CustomerDetails details=new CustomerDetails(1001,"12-C, North Street	", "Pune", "MH");
		Customer customer=new Customer("Tom", "1234567980", details);
		
		session.save(customer);
		session.save(details);
		session.getTransaction().commit();
		session.close();
		
		
	}

}
