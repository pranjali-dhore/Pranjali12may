package org.capgemini.demo;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BookId implements Serializable {
	
	private int bookId;
	private int courseId;
	
	public BookId(){}
	
	
	
	public BookId(int bookId, int courseId) {
		super();
		this.bookId = bookId;
		this.courseId = courseId;
	}



	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	@Override
	public String toString() {
		return "BookId [bookId=" + bookId + ", courseId=" + courseId + "]";
	}
	
	
	

}
