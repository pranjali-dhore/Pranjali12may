package org.capgemini.demo;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@NamedNativeQuery(query="select * from StudentInfo",name="selectAll",
		resultClass=Student.class)
@NamedQuery(query="select new Student(studId,firstName) from Student where feesAmt>8000",name="byFees")
//@NamedQuery(query="from Student",name="selectAll")
@Entity
@Table(name="StudentInfo")
public class Student {
	
	@Id
	@GeneratedValue
	private int studId;
	
	@Column(name="Student_First_Name",length=100)
	private String firstName;
	
	@Transient
	private String lastName;
	
	@Column(nullable=false)
	private String emailId;
	
	@Basic
	private double feesAmt;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date studDob;
	
	
	public Student(){}
	
	public Student(int studId, String firstName) {
		super();
		this.studId = studId;
		this.firstName = firstName;
		//this.lastName = lastName;
	}
	
	public Student(int studId, String firstName, String lastName) {
		super();
		this.studId = studId;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public Student( String firstName, String lastName) {
		super();

		this.firstName = firstName;
		this.lastName = lastName;
	}


	public Student(int studId, String firstName, String lastName, String emailId, double feesAmt, Date studDob) {
		super();
		this.studId = studId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.feesAmt = feesAmt;
		this.studDob = studDob;
	}
	public Student( String firstName, String lastName, String emailId, double feesAmt, Date studDob) {
		super();
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.feesAmt = feesAmt;
		this.studDob = studDob;
	}


	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	
	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public double getFeesAmt() {
		return feesAmt;
	}



	public void setFeesAmt(double feesAmt) {
		this.feesAmt = feesAmt;
	}



	public Date getStudDob() {
		return studDob;
	}



	public void setStudDob(Date studDob) {
		this.studDob = studDob;
	}



	@Override
	public String toString() {
		return "Student [studId=" + studId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId="
				+ emailId + ", feesAmt=" + feesAmt + ", studDob=" + studDob + "]";
	}



	

}
