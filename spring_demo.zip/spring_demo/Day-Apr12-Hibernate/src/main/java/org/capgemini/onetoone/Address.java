package org.capgemini.onetoone;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	private int addressId;
	private String doorNo;
	private String address;
	private String city;
	private String state;
	

		
	public Address(){}
	
	
	
	public Address(int addressId, String doorNo, String address, String city, String state) {
		super();
		this.addressId = addressId;
		this.doorNo = doorNo;
		this.address = address;
		this.city = city;
		this.state = state;
		
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNo=" + doorNo + ", address=" + address + ", city=" + city
				+ ", state=" + state +  "]";
	}
	
	

}
